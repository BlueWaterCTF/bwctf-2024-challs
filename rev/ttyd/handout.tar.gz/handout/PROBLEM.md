# TTYD: The Cryptic Letter

> Me: Mom can we get the remake for TTYD?
> Mom: We have a remake of TTYD at home.
> Remake at home:

Use the TTYD US iso file. Command to patch binary:
```sh
./mpatch -s TTYD_US.iso -p mod.xdelta -o output_mod.iso
```


